'use client';
import Spline from '@splinetool/react-spline';
import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function Hero() {
  const tl = useRef(gsap.timeline());
  const title = useRef(null);
  const subtitle = useRef(null);
  const btn = useRef(null);

  useEffect(() => {
    tl.current
      .from(title.current, { y: 50, opacity: 0, duration: 0.8 })
      .from(subtitle.current, { y: 50, opacity: 0, duration: 0.8 }, '-=0.4')
      .from(btn.current, { scale: 0.8, opacity: 0, duration: 0.5 }, '-=0.3');
  }, []);

  return (
    <section className="flex flex-col md:flex-row h-screen px-6 md:px-20 items-center bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      <div className="md:w-1/2 text-center md:text-left space-y-6">
        <h1 ref={title} className="text-5xl font-extrabold leading-tight">
          Crafting digital experiences in 3D
        </h1>
        <p ref={subtitle} className="text-lg text-gray-300 max-w-md mx-auto md:mx-0">
          From concept to code, we shape immersive web solutions.
        </p>
        <button
          ref={btn}
          className="px-8 py-3 bg-teal-400 text-gray-900 rounded-lg hover:bg-teal-300 transition"
        >
          View Projects
        </button>
      </div>
      <div className="md:w-1/2 w-full h-72 md:h-full mt-10 md:mt-0">
        <Spline scene="https://prod.spline.design/demo-link/scene.splinecode" />
      </div>
    </section>
  );
}
